//
//  CoreDatabaseManager.swift
//  SAMUH
//
//  Created by Jigar Khatri on 13/07/21.
//

import Foundation
import CoreData

enum uploadType: String {
    case image
    case video
    case hours
}

extension uploadType {
    var rawValue: String {
        switch self {
        case .image:
            return "image"
            
        case .video:
            return "video"
            
        case .hours:
            return "hours"
        }
    }
}




class CoreDBManager: NSObject {
    
    static let sharedDatabase = CoreDBManager()
    
    // MARK: - Core Data stack
    lazy var applicationDocumentsDirectory: URL = {
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return urls[urls.count-1]
    }()
    
    lazy var managedObjectModel: NSManagedObjectModel = {
        let modelURL = Bundle.main.url(forResource: "RentnKingDataBase", withExtension: "momd")!
        return NSManagedObjectModel(contentsOf: modelURL)!
    }()
    
    lazy var persistentStoreCoordinator: NSPersistentStoreCoordinator = {
        
        let coordinator = NSPersistentStoreCoordinator(managedObjectModel: self.managedObjectModel)
        let url = self.applicationDocumentsDirectory.appendingPathComponent("RentnKingDataBase.sqlite")
//        UserDefaultManager.setStringToUserDefaults(value: url.path, key: LOCAL_DATABASE_PATH)
        
        var failureReason = "There was an error creating or loading the application's saved data."
        do {
            try coordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: url, options: nil)
        } catch {
            
            var dict = [String: AnyObject]()
            dict[NSLocalizedDescriptionKey] = "Failed to initialize the application's saved data" as AnyObject?
            dict[NSLocalizedFailureReasonErrorKey] = failureReason as AnyObject?
            
            dict[NSUnderlyingErrorKey] = error as NSError
            let wrappedError = NSError(domain: "YOUR_ERROR_DOMAIN", code: 9999, userInfo: dict)
            NSLog("Unresolved error \(wrappedError), \(wrappedError.userInfo)")
            abort()
        }
        
        return coordinator
    }()
    
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "RentnKingDataBase")
        let url = self.applicationDocumentsDirectory.appendingPathComponent("RentnKingDataBase.sqlite")
        NSLog("Database Path: \(url)")
      //  UserDefaultManager.setStringToUserDefaults(value: url.path, key: LOCAL_DATABASE_PATH)
        
        /*add necessary support for migration*/
        let description = NSPersistentStoreDescription(url: url)
        description.shouldMigrateStoreAutomatically = true
        description.shouldInferMappingModelAutomatically = true
        container.persistentStoreDescriptions =  [description]
        /*add necessary support for migration*/
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    
    lazy var managedObjectContext: NSManagedObjectContext = {        return CoreDBManager.sharedDatabase.persistentContainer.viewContext
    }()
    
    // MARK: - Core Data Saving support
    
    func saveContext () {
        if managedObjectContext.hasChanges {
            DispatchQueue.main.async {
                do {
                    try self.managedObjectContext.save()
                } catch {
                    let nserror = error as NSError
                    NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
                }
            }
            
        }
    }
    
    
    //==== GET DATA ==== //
    func getAllUploadDATA() -> [OrderList]{
        let objContext = self.managedObjectContext
        let fetchRequest = NSFetchRequest<OrderList>(entityName: "OrderList")
        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "OrderList", in: objContext)!
        fetchRequest.entity = disentity
        
        do{
            return try managedObjectContext.fetch(fetchRequest)
        }
        catch
        {
            return []
        }
    }

//    func getOrderListData(strOrderID : String, strType : String) -> [OrderList]{
//        
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<OrderList>(entityName: "OrderList")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "OrderList", in: objContext)!
//        
//        let predicate0_1 = NSPredicate(format:"orderID == %@",strOrderID)
//        let predicate0_2 = NSPredicate(format:"type == %@",strType)
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1,predicate0_2])
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            return try managedObjectContext.fetch(fetchRequest)
//        }
//        catch
//        {
//            return []
//        }
//    }
    
    func getUploadListData(strOrderID : String, strType : String) -> [UploadData]{
        
        let objContext = self.managedObjectContext
        let fetchRequest = NSFetchRequest<UploadData>(entityName: "UploadData")
        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "UploadData", in: objContext)!
        
        let predicate0_1 = NSPredicate(format:"orderID == %@",strOrderID)
        let predicate0_2 = NSPredicate(format:"type == %@",strType)
        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2])
        
        fetchRequest.predicate = predicate1
        fetchRequest.entity = disentity
        
        do{
            return try managedObjectContext.fetch(fetchRequest)
        }
        catch
        {
            return []
        }
    }
    

    
    //====SAVE DATABASE=====
//    func saveOrderList(strOrderID : String, strType : String ,complete:@escaping (_ isSave:Bool) -> ()){
//
//        
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<OrderList>(entityName: "OrderList")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "OrderList", in: objContext)!
//        let predicate0_1 = NSPredicate(format:"orderID == \(strOrderID)")
//        let predicate0_2 = NSPredicate(format:"type == %@",strType)
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2])
//        
//
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            var objCDDownload:OrderList!
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [UploadData]
//            if(results.count == 0)
//            {
//                
//                objCDDownload = (NSEntityDescription.insertNewObject(forEntityName:"OrderList",into:managedObjectContext) as? OrderList)!
//                
//                objCDDownload.orderID = strOrderID
//                objCDDownload.type = strType
//                
//                self.saveContext()
//                complete(true)
//            }
//        }
//        catch
//        {
//            print("CHAT SYNCH FAILED")
//        }
//        
//    }
    
    
    func saveUploadDataList(objSaveData:SaveImageVideoParameater ,complete:@escaping (_ isSave:Bool) -> ()){

        
        let objContext = self.managedObjectContext
        let fetchRequest = NSFetchRequest<UploadData>(entityName: "UploadData")
        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "UploadData", in: objContext)!
        let predicate0_1 = NSPredicate(format:"orderID == %@","\(objSaveData.orderID)")
        let predicate0_2 = NSPredicate(format:"type == %@","\(objSaveData.type)")
        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2])
        

        fetchRequest.predicate = predicate1
        fetchRequest.entity = disentity
        
        do{
            var objCDDownload:UploadData!
            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [UploadData]
            if(results.count == 0)
            {
                
                objCDDownload = (NSEntityDescription.insertNewObject(forEntityName:"UploadData",into:managedObjectContext) as? UploadData)!
                
                objCDDownload.orderID = objSaveData.orderID
                objCDDownload.name = objSaveData.name
                objCDDownload.isImage = objSaveData.isImage
                objCDDownload.type = objSaveData.type
                
                self.saveContext()
                complete(true)
                //SAVE SHOW VIDEO OR DOWNALOAD
               
            }
        }
        catch
        {
            print("CHAT SYNCH FAILED")
        }
        
    }


   
    
    //====DELETE DATABASE ===
    func deleteUploadData(strOrderID : String, strType : String, complete:@escaping (_ isSave:Bool) -> ()){
        
        let objContext = self.managedObjectContext
        let fetchRequest = NSFetchRequest<UploadData>(entityName: "UploadData")
        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "UploadData", in: objContext)!

        let predicate0_1 = NSPredicate(format:"orderID == %@","\(strOrderID)")
        let predicate0_2 = NSPredicate(format:"type == %@","\(strType)")
        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2])
        
        fetchRequest.predicate = predicate1
        fetchRequest.entity = disentity
      
        
        do{
            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [UploadData]
          
            for obj in results{
                managedObjectContext.delete(obj)
            }
            
            self.saveContext()
            complete(true)

        }
        catch
        {
            print("CHAT SYNCH FAILED")
        }
    }
    
    //====UPDATE DATABASE=====
//    func updateDownalodURL(objSaveData:SaveImageVideoParameater, complete:@escaping (_ isSave:Bool) -> ()){
//        
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<UploadData>(entityName: "UploadData")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "UploadData", in: objContext)!
//
//        let predicate0_1 = NSPredicate(format:"orderID == \(objSaveData.orderID)")
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1])
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//      
//        
//        do{
//            var objCDDownloadShow:UploadData!
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [UploadData]
//            if(results.count != 0)
//            {
//                let obj = results[0]
//                objCDDownloadShow = results[0] as UploadData
//                objCDDownloadShow.download_percentage = download_percentage
//                objCDDownloadShow.isDownload = isisDownload
//                objCDDownloadShow.show_id = obj.show_id
//                objCDDownloadShow.video_id = obj.video_id
//                objCDDownloadShow.video_name = obj.video_name
//                objCDDownloadShow.video_url = obj.video_url
//                objCDDownloadShow.download_URL = FileName
//                objCDDownloadShow.session_id = sessionID
//                self.saveContext()
//                complete(true)
//            }
//            else{
//                complete(false)
//            }
//        }
//        catch
//        {
//            print("CHAT SYNCH FAILED")
//        }
//        
//    }
//    
//    func updateDownalodPresontageURL(videoID : String, percentage : String, isPush : String, complete:@escaping (_ isSave:Bool) -> ()){
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<Download>(entityName: "Download")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "Download", in: objContext)!
//        let predicate1 = NSPredicate(format:"video_id == \(videoID)")
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            var objCDDownloadShow:Download!
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [Download]
//            if(results.count != 0)
//            {
//                
//                objCDDownloadShow = results[0] as Download
//                objCDDownloadShow.download_percentage = percentage
//                objCDDownloadShow.isDownload = objCDDownloadShow.isDownload
//                objCDDownloadShow.show_id = objCDDownloadShow.show_id
//                objCDDownloadShow.video_id = objCDDownloadShow.video_id
//                objCDDownloadShow.video_name = objCDDownloadShow.video_name
//                objCDDownloadShow.video_url = objCDDownloadShow.video_url
//                objCDDownloadShow.download_URL = objCDDownloadShow.download_URL
//                objCDDownloadShow.isPush = isPush
//                self.saveContext()
//                complete(true)
//            }
//            else{
//                complete(false)
//            }
//        }
//        catch
//        {
//            print("CHAT SYNCH FAILED")
//        }
//        
//    }
//    
//
//    
//    func updateExpityDownalodVideo(showID : String, videoID : String, downloadId : String, expiryDate : String, isDownload : String, complete:@escaping (_ isSave:Bool) -> ()){
//        
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<Download>(entityName: "Download")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "Download", in: objContext)!
//
//        let predicate0_1 = NSPredicate(format:"show_id == %@",showID)
//        let predicate0_2 = NSPredicate(format:"video_id == %@",videoID)
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2])
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//      
//        
//        do{
//            var objCDDownloadShow:Download!
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [Download]
//            if(results.count != 0)
//            {
//                objCDDownloadShow = results[0] as Download
//                objCDDownloadShow.expiry_date = expiryDate
//                objCDDownloadShow.download_ID = downloadId
//                objCDDownloadShow.isDownload = isDownload
//
//                self.saveContext()
//                complete(true)
//            }
//            else{
//                complete(false)
//            }
//        }
//        catch
//        {
//            print("CHAT SYNCH FAILED")
//        }
//        
//    }
//    
//    
//    //    ======DELETE=====
//    
//    func deleteShows(strShowID:String, strProfileID:String,complete:(_ isDone:Bool) -> ()){
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<DownloadList>(entityName: "DownloadList")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "DownloadList", in: objContext)!
//     
//        let predicate0_1 = NSPredicate(format:"show_id == %@",strShowID)
//        let predicate0_2 = NSPredicate(format:"profile_id == %@",strProfileID)
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2])
//     
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [DownloadList]
//            if(results.count != 0)
//            {
//                for result in results {
//                    objContext.delete(result)
//                }
//            }
//            self.saveContext()
//            complete(true)
//        }
//        catch
//        {
//            complete(false)
//        }
//    }
//    
//    
//    func deleteVideos(showID : String, videoID : String, strProfileID : String,complete:(_ isDone:Bool) -> ()){
//        //DELETE SUBTITL
//        if let objUser = UserDefaults.standard.user{
//            deleteSubTitle(strVideoID: videoID, strProfileID: strProfileID, strUserID: objUser.id ?? "") { isSave in
//            }
//        }
//
//        
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<Download>(entityName: "Download")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "Download", in: objContext)!
//
//        let predicate0_1 = NSPredicate(format:"show_id == %@",showID)
//        let predicate0_2 = NSPredicate(format:"video_id == %@",videoID)
//        let predicate0_3 = NSPredicate(format:"profile_id == %@",strProfileID)
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2, predicate0_3])
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [Download]
//            if(results.count != 0)
//            {
//                for result in results {
//                    objContext.delete(result)
//                }
//            }
//            self.saveContext()
//            complete(true)
//        }
//        catch
//        {
//            complete(false)
//        }
//    }
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    //====SAVE SUBTITLE DATABASE=====
//    func saveSubtitleList(objSaveData:SaveSubTitleParameater ,strProfileID : String, strUserID : String ,complete:@escaping (_ isSave:Bool) -> ()){
//       
//        
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<VideoSubtitle>(entityName: "VideoSubtitle")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "VideoSubtitle", in: objContext)!
//        let predicate0_1 = NSPredicate(format:"video_id == \(objSaveData.video_id)")
//        let predicate0_2 = NSPredicate(format:"profile_id == %@",strProfileID)
//        let predicate0_3 = NSPredicate(format:"userID == %@",strUserID)
//
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2, predicate0_3])
//
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            var objCDDownload:VideoSubtitle!
//            objCDDownload = (NSEntityDescription.insertNewObject(forEntityName:"VideoSubtitle",into:managedObjectContext) as? VideoSubtitle)!
//            
//            objCDDownload.profile_id = strProfileID
//            objCDDownload.userID = strUserID
//            objCDDownload.lung = objSaveData.lung
//            objCDDownload.subTitleUrl = objSaveData.subTitleUrl
//            objCDDownload.video_id = objSaveData.video_id
//
//            self.saveContext()
//            complete(true)
//            
//            
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [VideoSubtitle]
//            if(results.count == 0)
//            {
//
//
//            }
//
//        }
//        catch
//        {
//            print("CHAT SYNCH FAILED")
//        }
//        
//    }
//    
//    func getSubtitleDataDData(strVideoID : String, strProfileID : String, strUserID : String) -> [VideoSubtitle]{
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<VideoSubtitle>(entityName: "VideoSubtitle")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "VideoSubtitle", in: objContext)!
//        
//        let predicate0_1 = NSPredicate(format:"video_id == %@",strVideoID)
//        let predicate0_2 = NSPredicate(format:"profile_id == %@",strProfileID)
//        let predicate0_3 = NSPredicate(format:"userID == %@",strUserID)
//
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2, predicate0_3])
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            
//            return try managedObjectContext.fetch(fetchRequest)
//
//        }
//        catch
//        {
//            return []
//        }
//    }
//    
//    func deleteSubTitle(strVideoID : String, strProfileID : String, strUserID : String,complete:(_ isDone:Bool) -> ()){
//
//        let objContext = self.managedObjectContext
//        let fetchRequest = NSFetchRequest<VideoSubtitle>(entityName: "VideoSubtitle")
//        let disentity: NSEntityDescription = NSEntityDescription.entity(forEntityName: "VideoSubtitle", in: objContext)!
//     
//        let predicate0_1 = NSPredicate(format:"video_id == %@",strVideoID)
//        let predicate0_2 = NSPredicate(format:"profile_id == %@",strProfileID)
//        let predicate0_3 = NSPredicate(format:"userID == %@",strUserID)
//        let predicate1 = NSCompoundPredicate.init(type: .and, subpredicates: [predicate0_1, predicate0_2, predicate0_3])
//     
//        
//        fetchRequest.predicate = predicate1
//        fetchRequest.entity = disentity
//        
//        do{
//            let results = try  managedObjectContext.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>) as! [VideoSubtitle]
//            if(results.count != 0)
//            {
//                for result in results {
//                    let strDownloadURL : NSString = ("\(subTitleDirectory)" as NSString).appendingPathComponent(result.subTitleUrl ?? "") as NSString
//                    try? FileManager.default.removeItem(atPath: "\(strDownloadURL)")
//
//                    objContext.delete(result)
//                }
//            }
//            self.saveContext()
//            complete(true)
//        }
//        catch
//        {
//            complete(false)
//        }
//    }
    
    

}




